import logging


class ConfigurationMyOdt:
    # logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=u'mylog.log')
    # logger = logging.getLogger()
    path_template_folder = './templates_odf/'

    # @classmethod
    # def set_loger(self, logger_in):
    #     self.logger = logger_in