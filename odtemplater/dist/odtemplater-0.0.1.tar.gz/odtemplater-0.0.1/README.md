# ODTemplater

Пакет `ODTemplater` выполняет функции наполнения данными подготовленного шаблона в формате `*.ODT`. 

[Документация](https://github.com/myzxzrus/ODTemplater/tree/main/doc "")

