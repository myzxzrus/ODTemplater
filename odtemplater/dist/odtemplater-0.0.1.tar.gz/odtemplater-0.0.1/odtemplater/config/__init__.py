from .config import ConfigurationMyOdt
